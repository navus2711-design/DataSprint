import plotly.graph_objects as go
import plotly.express as px

# Data from the provided JSON
categories = ["Physical Prototyping Cost (per iteration)", "Development Time (days)", "Training Cost (per learner)", "Safety Incidents (per 100 workers)", "Collaboration Efficiency (%)"]
traditional_values = [3500, 21, 986, 2.8, 40]
immersive_values = [750, 3, 300, 0.5, 85]
units = ["$", "days", "$", "incidents", "%"]

# Abbreviate category names to fit 15 character limit
categories_short = ["Prototype Cost", "Dev Time", "Training Cost", "Safety Inc.", "Collab Eff."]

# Create grouped bar chart
fig = go.Figure()

# Add traditional methods bar
fig.add_trace(go.Bar(
    name='Traditional',
    x=categories_short,
    y=traditional_values,
    marker_color='#DB4545',  # Bright red
    text=[f"${3.5}k" if i==0 else f"{986}" if i==2 else f"{v}" for i, v in enumerate(traditional_values)],
    textposition='auto',
))

# Add immersive methods bar
fig.add_trace(go.Bar(
    name='Immersive VR',
    x=categories_short,
    y=immersive_values,
    marker_color='#1FB8CD',  # Strong cyan
    text=[f"${750}" if i==0 else f"${300}" if i==2 else f"{v}" for i, v in enumerate(immersive_values)],
    textposition='auto',
))

# Update layout
fig.update_layout(
    title='Industrial Prototyping: Cost & Time Comparison',
    xaxis_title='Metrics',
    yaxis_title='Values',
    barmode='group',
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5)
)

# Update traces
fig.update_traces(cliponaxis=False)

# Save as PNG
fig.write_image('industrial_prototyping_comparison.png')