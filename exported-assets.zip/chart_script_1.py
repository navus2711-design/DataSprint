import plotly.graph_objects as go
import plotly.express as px
import json

# Load the data
data = {"components": [{"layer": "Input Layer", "items": ["CAD Data Import", "Physical Constraints", "Design Requirements", "Material Properties"]}, {"layer": "Processing Layer", "items": ["Cloud Infrastructure", "AI Simulation Engine", "Real-time Rendering", "Physics Engine"]}, {"layer": "Immersive Interface", "items": ["VR/AR Headsets", "Collaborative Spaces", "Haptic Feedback", "Gesture Controls"]}, {"layer": "Collaboration Tools", "items": ["Multi-user Access", "Version Control", "Communication Tools", "Design Review"]}, {"layer": "Output Layer", "items": ["Design Validation", "Performance Analytics", "Export Capabilities", "Documentation"]}]}

# Define colors for each layer
colors = ['#1FB8CD', '#DB4545', '#2E8B57', '#5D878F', '#D2BA4C']

# Create positions for each component with consistent spacing
x_positions = []
y_positions = []
labels = []
layer_colors = []

# Position components with consistent vertical and horizontal spacing
layer_y_positions = [8, 6, 4, 2, 0]  # Even spacing between layers
box_width = 1.2
box_height = 0.6

for i, layer_data in enumerate(data['components']):
    layer = layer_data['layer']
    items = layer_data['items']
    
    # Calculate x positions for items in this layer with consistent spacing
    n_items = len(items)
    total_width = (n_items - 1) * 2.0  # Consistent 2.0 spacing between boxes
    x_start = -total_width / 2
    
    for j, item in enumerate(items):
        x_positions.append(x_start + j * 2.0)
        y_positions.append(layer_y_positions[i])
        
        # Abbreviate item names more carefully to fit 15-char limit
        item_abbrev = item.replace('Infrastructure', 'Infra').replace('Engine', 'Eng')
        item_abbrev = item_abbrev.replace('Constraints', 'Constrs').replace('Requirements', 'Reqs')
        item_abbrev = item_abbrev.replace('Analytics', 'Analytics').replace('Capabilities', 'Caps')
        item_abbrev = item_abbrev.replace('Collaborative', 'Collab').replace('Communication', 'Comm')
        item_abbrev = item_abbrev.replace('Real-time', 'RT').replace('Multi-user', 'Multi-usr')
        item_abbrev = item_abbrev.replace('Performance', 'Perf').replace('Documentation', 'Docs')
        item_abbrev = item_abbrev.replace('Physical', 'Phys').replace('Material', 'Mat')
        item_abbrev = item_abbrev.replace('Properties', 'Props').replace('Rendering', 'Render')
        item_abbrev = item_abbrev.replace('Validation', 'Valid').replace('Controls', 'Ctrls')
        item_abbrev = item_abbrev[:15]  # Ensure 15 char limit
        
        labels.append(item_abbrev)
        layer_colors.append(colors[i])

# Create the figure
fig = go.Figure()

# Add rectangular boxes for each component with consistent sizing
for i, (x, y, label, color) in enumerate(zip(x_positions, y_positions, labels, layer_colors)):
    # Add rectangle shape with consistent dimensions
    fig.add_shape(
        type="rect",
        x0=x-box_width/2, y0=y-box_height/2, 
        x1=x+box_width/2, y1=y+box_height/2,
        fillcolor=color,
        line=dict(color='white', width=2)
    )
    
    # Add text label with larger font
    fig.add_trace(go.Scatter(
        x=[x],
        y=[y],
        mode='text',
        text=[label],
        textfont=dict(size=12, color='white', family='Arial'),
        hovertemplate=f'{label}<extra></extra>',
        showlegend=False
    ))

# Add straight, well-aligned arrows between layer centers
for i in range(len(layer_y_positions) - 1):
    current_layer_y = layer_y_positions[i]
    next_layer_y = layer_y_positions[i + 1]
    
    # Calculate center x position for each layer
    current_layer_x_positions = [x for x, y in zip(x_positions, y_positions) if y == current_layer_y]
    next_layer_x_positions = [x for x, y in zip(x_positions, y_positions) if y == next_layer_y]
    
    current_center_x = sum(current_layer_x_positions) / len(current_layer_x_positions)
    next_center_x = sum(next_layer_x_positions) / len(next_layer_x_positions)
    
    # Add straight arrow line
    fig.add_trace(go.Scatter(
        x=[current_center_x, next_center_x],
        y=[current_layer_y - box_height/2 - 0.1, next_layer_y + box_height/2 + 0.1],
        mode='lines',
        line=dict(color='#13343B', width=3),
        hoverinfo='skip',
        showlegend=False
    ))
    
    # Add arrow head with consistent sizing
    arrow_size = 0.2
    fig.add_trace(go.Scatter(
        x=[next_center_x - arrow_size, next_center_x, next_center_x + arrow_size, next_center_x - arrow_size],
        y=[next_layer_y + box_height/2 + 0.1 + arrow_size, 
           next_layer_y + box_height/2 + 0.1, 
           next_layer_y + box_height/2 + 0.1 + arrow_size,
           next_layer_y + box_height/2 + 0.1 + arrow_size],
        mode='lines',
        line=dict(color='#13343B', width=3),
        fill='toself',
        fillcolor='#13343B',
        hoverinfo='skip',
        showlegend=False
    ))

# Add layer labels with better positioning and larger font
layer_label_names = [
    'Input Layer',
    'Processing Layer', 
    'Immersive IF',
    'Collab Tools',
    'Output Layer'
]

# Position layer labels further from the main chart area
for i, (layer_y, layer_name) in enumerate(zip(layer_y_positions, layer_label_names)):
    fig.add_trace(go.Scatter(
        x=[-6],
        y=[layer_y],
        mode='text',
        text=[layer_name],
        textfont=dict(size=16, color=colors[i], family='Arial Black'),
        hoverinfo='skip',
        showlegend=False
    ))

# Update layout with larger, bolder title
fig.update_layout(
    title=dict(
        text='Industrial Prototyping Platform',
        font=dict(size=22, color='#13343B', family='Arial Black'),
        x=0.5,
        xanchor='center',
        y=0.95
    ),
    showlegend=False,
    plot_bgcolor='rgba(0,0,0,0)',
    paper_bgcolor='rgba(0,0,0,0)',
)

# Update axes with appropriate ranges for the improved spacing
fig.update_xaxes(
    showgrid=False,
    showticklabels=False,
    zeroline=False,
    range=[-8, 6]
)

fig.update_yaxes(
    showgrid=False,
    showticklabels=False,
    zeroline=False,
    range=[-1, 9]
)

# Update traces
fig.update_traces(cliponaxis=False)

# Save the chart
fig.write_image('industrial_prototyping_flowchart.png')